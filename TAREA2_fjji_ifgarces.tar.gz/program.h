/*
Do not modify this file.
Make all of your changes to main.c instead.
*/

#ifndef PROGRAM_H
#define PROGRAM_H

void access_pattern1( char* data, int length );
void access_pattern2( char* data, int length );
void access_pattern3( char* data, int length );

#endif
